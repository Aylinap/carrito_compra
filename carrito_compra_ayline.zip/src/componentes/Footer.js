import React from "react";

export default function Footer(){
    return (
        <div className="justify-content-center mt-10" style={{background: '#ffa500', padding: '20px', marginTop: '20px' }}>
            <h6 className="text-center">&copy; Todos los derechos reservados de Tiendita inglesa </h6>
        </div>
    )
}