import React from 'react';
import Carrito from '../componentes/Carrito';

export default function CarritoPage() {
    return (
      <div className="container mt-4">
        <Carrito />
      </div>
    );
};


